# Security Policy

## Supported Versions

Only the latest released version is supported.
To facilitate upgrades we almost never make backwards-incompatible changes.

## Reporting a Vulnerability

Please report vulnerabilities over email, by sending an email to `maggus.staab+jqvalidate` at `gmail` dot `com`.
